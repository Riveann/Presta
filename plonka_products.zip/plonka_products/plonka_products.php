<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class plonka_products extends Module
{
    
    
    public function __construct()
    {
        $this->name = 'plonka_products';
        $this->tab = 'front_office_features';
        $this->version = '1.0.65';
        $this->author = 'Plonka';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.7',
            'max' => _PS_VERSION_
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Display products');
        $this->description = $this->l('Display products on homepage');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
      
    }
    public function install()
    {
        if (!parent::install()
            || !$this->registerHook('displayHome')
        ) {
            return false;
        }
        return true;
    } 
   
    public function uninstall()
    {
        return parent::uninstall();
    }


    public function hookDisplayHome($params)
    {
        $content1 = $this->show(Configuration::get('cat1'));
        $content2 = $this->show(Configuration::get('cat2'));
        $content2 = $this->show(Configuration::get('cat3'));


        $this->setMedia();

         return $this->display(__FILE__, 'display_product.tpl');
     
    }



    public function displayForm()
{
   
   $fields_form[0]['form'] = array(
    'legend' => array(
        'title' => $this->l('YouTube Module'),
    ),
    'input' => array(
        array(
            'type' => 'text',
            'label' => $this->l('ID category 1'),
            'name' => 'cat1',
            'size' => 20,
            'required' => true
        ),
        array(
            'type' => 'text',
            'label' => $this->l('ID category 2'),
            'name' => 'cat2',
            'size' => 20,
            'required' => true
        ),
        array(
            'type' => 'text',
            'label' => $this->l('ID category 3'),
            'name' => 'cat3',
            'size' => 20,
            'required' => true
        ),
    ),
    'submit' => array(
        'title' => $this->l('Save'),
        'class' => 'btn btn-default pull-right'
    )
);

    $helper = new HelperForm();

 
    $helper->module = $this;
    $helper->name_controller = $this->name;
    $helper->token = Tools::getAdminTokenLite('AdminModules');
    $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

   
    $helper->title = $this->displayName;
    $helper->show_toolbar = true;      
    $helper->toolbar_scroll = true;   
    $helper->submit_action = 'submit'.$this->name;
    $helper->toolbar_btn = array(
        'save' =>
            array(
                'desc' => $this->l('Save'),
                'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
                    '&token='.Tools::getAdminTokenLite('AdminModules'),
            ),
        'back' => array(
            'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->l('Back to list')
        )
    );

    // < load current value >
    $helper->fields_value['cat1'] = Configuration::get('cat1');

    $helper->fields_value['cat2'] = Configuration::get('cat2');

    $helper->fields_value['cat3'] = Configuration::get('cat3');

    return $helper->generateForm($fields_form);

    $helper->fields_value['cat1'] = Configuration::get('cat1');

    
    $helper->fields_value['cat2'] = Configuration::get('cat2');

    $helper->fields_value['cat3'] = Configuration::get('cat3');
}
    
public function getContent()
{
    $output = null;


  
    if (Tools::isSubmit('submit'.$this->name)) {
        $cat1 = strval(Tools::getValue('cat1'));
        $cat2 = strval(Tools::getValue('cat2'));
        $cat3 = strval(Tools::getValue('cat3'));
        
        if (!isset($cat1) && !isset($cat2) && !isset($cat3))
            $output .= $this->displayError($this->l('Please insert something in this field.'));
        else
        {
            
            Configuration::updateValue('cat1', $cat1);
            Configuration::updateValue('cat2', $cat2);
            Configuration::updateValue('cat3', $cat3);

           
            $output .= $this->displayConfirmation($this->l('Fields got update'));
        }
    }

    

    return $output.$this->displayForm();
}


public function setMedia()
{
    $this->context->controller->registerStylesheet(
        'modules-jest',
        'modules/'.$this->name.'/customo.css',
        array('media' => 'all', 'priority' => 150)
    );

    $this->context->controller->registerJavascript(
        'modules-jest-js',
        'modules/'.$this->name.'/customo.js',
        array('media' => 'all', 'attribute' => 'async')
    );
}

public function show($prm){
    $cat1 = Configuration::get('cat1');
    $cat2 = Configuration::get('cat2');
    $cat3 = Configuration::get('cat3');
    $productArray = Product::getProducts(Context::getContext()->language->id, 0, NULL, 'reference', 'ASC', Configuration::get('cat1'));
    $productArray2 = Product::getProducts(Context::getContext()->language->id, 0, NULL, 'reference', 'ASC', Configuration::get('cat2'));
    $productArray3 = Product::getProducts(Context::getContext()->language->id, 0, NULL, 'reference', 'ASC', Configuration::get('cat3'));
    $categoryData = new Category (Configuration::get('cat1'),Context::getContext()->language->id);
    $name = $categoryData->name;
    $categoryData2 = new Category (Configuration::get('cat2'),Context::getContext()->language->id);
    $name2 = $categoryData2->name;
    $categoryData3= new Category (Configuration::get('cat3'),Context::getContext()->language->id);
    $name3 = $categoryData3->name;


        $this->context->smarty->assign(
            array('productArray' => $productArray, 'productArray2' => $productArray2, 'productArray3' => $productArray3, 'catName' => $name, 'catName2' => $name2, 'catName3' => $name3, 'cat3' => $cat3, 
            'cat2' => $cat2, 'cat1' => $cat1, 'image' => $imagePath, 'imagedisp' => $this->image())
        );

      
      return;
}
public function image()
{
    $id_lang = (int) Configuration::get('PS_LANG_DEFAULT');
    $image = Image::getCover($id_product);
    $product = new Product($id_product);
    $link = new Link;


    $imagePath = $link->getImageLink($product->link_rewrite[Context::getContext()->language->id], $image['id_image'].$id_product, 'home_default');


    return $imagePath;

}




}

