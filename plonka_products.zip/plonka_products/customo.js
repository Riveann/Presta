var perPage = 3;

new List("test-list", {
  valueNames: ["name"],
  page: perPage,
  plugins: [
    // can not make left and right work on List.js 1.5.0, so I use 1.3.0 instead, which requires List.pagination.js plugin
    ListPagination({
      paginationClass: "pagination-layout",
      left: 2,
      right: 2
    })
  ]
}).on("updated", function(list) {
  var isFirst = list.i == 1;
  var isLast = list.i > list.matchingItems.length - list.page;

  // make the Prev and Nex buttons disabled on first and last pages accordingly
  $(".pagination-prev.disabled, .pagination-next.disabled").removeClass(
    "disabled"
  );
  if (isFirst) {
    $(".pagination-prev").addClass("disabled");
  }
  if (isLast) {
    $(".pagination-next").addClass("disabled");
  }

  // hide pagination if there one or less pages to show
  if (list.matchingItems.length <= perPage) {
    $(".pagination-wrap").hide();
  } else {
    $(".pagination-wrap").show();
  }
});

$(".pagination-next").click(function() {
  $(".pagination-layout .active")
    .next()
    .trigger("click");
});
$(".pagination-prev").click(function() {
  $(".pagination-layout .active")
    .prev()
    .trigger("click");
});



new List("test-list2", {
  valueNames: ["name"],
  page: perPage,
  plugins: [
    // can not make left and right work on List.js 1.5.0, so I use 1.3.0 instead, which requires List.pagination.js plugin
    ListPagination({
      paginationClass: "pagination-layout2",
      left: 2,
      right: 2
    })
  ]
}).on("updated", function(list) {
  var isFirst = list.i == 1;
  var isLast = list.i > list.matchingItems.length - list.page;

  // make the Prev and Nex buttons disabled on first and last pages accordingly
  $(".pagination-prev2.disabled, .pagination-next2.disabled").removeClass(
    "disabled"
  );
  if (isFirst) {
    $(".pagination-prev2").addClass("disabled");
  }
  if (isLast) {
    $(".pagination-next2").addClass("disabled");
  }

  // hide pagination if there one or less pages to show
  if (list.matchingItems.length <= perPage) {
    $(".pagination-wrap2").hide();
  } else {
    $(".pagination-wrap2").show();
  }
});

$(".pagination-next2").click(function() {
  $(".pagination-layout2 .active")
    .next()
    .trigger("click");
});
$(".pagination-prev2").click(function() {
  $(".pagination-layout2 .active")
    .prev()
    .trigger("click");
});

new List("test-list3", {
  valueNames: ["name"],
  page: perPage,
  plugins: [
    // can not make left and right work on List.js 1.5.0, so I use 1.3.0 instead, which requires List.pagination.js plugin
    ListPagination({
      paginationClass: "pagination-layout3",
      left: 2,
      right: 2
    })
  ]
}).on("updated", function(list) {
  var isFirst = list.i == 1;
  var isLast = list.i > list.matchingItems.length - list.page;

  // make the Prev and Nex buttons disabled on first and last pages accordingly
  $(".pagination-prev3.disabled, .pagination-next3.disabled").removeClass(
    "disabled"
  );
  if (isFirst) {
    $(".pagination-prev3").addClass("disabled");
  }
  if (isLast) {
    $(".pagination-next3").addClass("disabled");
  }

  // hide pagination if there one or less pages to show
  if (list.matchingItems.length <= perPage) {
    $(".pagination-wrap3").hide();
  } else {
    $(".pagination-wrap3").show();
  }
});

$(".pagination-next3").click(function() {
  $(".pagination-layout3 .active")
    .next()
    .trigger("click");
});
$(".pagination-prev3").click(function() {
  $(".pagination-layout3 .active")
    .prev()
    .trigger("click");
});


$('.image img').attr('src',$('.image img').attr('src').replace('pr/', ''))







